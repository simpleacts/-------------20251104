// FIX: Changed re-export to a more robust import/export syntax to avoid module resolution issues.
import AdminApp from './components/AdminApp';
export default AdminApp;